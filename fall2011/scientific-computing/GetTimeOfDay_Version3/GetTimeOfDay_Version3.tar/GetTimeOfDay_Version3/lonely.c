#include<stdio.h>
void function00();
void function01(double);
void function02(double,double);
void function03(double,double,double);
void function04(double,double,double,double);
void function05(double,double,double,double,double);
void function06(double,double,double,double,double,double);
void function07(double,double,double,double,double,double,double);
void function08(double,double,double,double,double,double,double,double);
void function09(double,double,double,double,double,double,double,double,double);
void function10(double,double,double,double,double,double,double,double,double,double);
void function12(double,double,double,double,double,double,double,double,double,double,double,double);
void function15(double,double,double,double,double,double,double,double,double,double,double,double,double,double,double);
void function25(double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,
				double,double,double,double,double,double,double,double,double,double);

/*
funtion with zero parameter
*/
void function00()
{
	int x1 = 3.2;
	return;
}

/*
funtion with 1 parameter
*/
void function01(double x1)
{
	x1=3.2;
	return;
}

/*
funtion with 2 parameter
*/
void function02(double x1, double x2)
{
	x1=3.2;
	return;
}

/*
funtion with 3 parameter
*/
void function03(double x1, double x2, double x3)
{
	x1=3.2;
	return;
}

/*
funtion with 4 parameter
*/
void function04(double x1, double x2, double x3, double x4)
{
	x1=3.2;
	return;
}
/*
funtion with 5 parameter
*/

void function05(double x1, double x2, double x3, double x4, double x5)
{
	x1=3.2;
	return;
}

/*
funtion with 6 parameter
*/
void function06(double x1, double x2, double x3, double x4, double x5, double x6)
{
	x1=3.2;
	return;
}

/*
funtion with 7 parameter
*/
void function07(double x1, double x2, double x3, double x4, double x5, double x6, double x7)
{
	x1=3.2;
	return;
}

/*
funtion with 8 parameter
*/
void function08(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8)
{
	x1=3.2;
	return;
}

/*
funtion with 9 parameter
*/
void function09(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9)
{
	x1=3.2;
	return;
}


void function10(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10)
{
	x1=3.2;
	return;
}

void function11(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11)
{
	x1=3.2;
	return;
}

void function12(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12)
{
	x1=3.2;
	return;
}


void function15(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15)
{
	x1=3.2;
	return;
}


void function25(double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15, double x16, double x17, double x18, double x19, double x20, double x21, double x22, double x23, double x24, double x25)
{
	x1=3.2;
	return;
}