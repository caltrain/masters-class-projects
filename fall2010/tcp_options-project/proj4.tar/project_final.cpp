#include <pcap.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <time.h>
#include<errno.h>
#include <map>
#include <string>
#include <iostream>
#include <sstream>
/* default snap length (maximum bytes per packet to capture) */
#define SNAP_LEN 1518
using namespace std;
/* ethernet headers are always exactly 14 bytes [1] */
#ifndef ETHER_HDRLEN
#define ETHER_HDRLEN 14
#define SIZE_ETHERNET 14
#endif


map<string,int> pack_size_client; 
    string pack_p_client;    
    
map<string,int> pack_size_server;
	string pack_p_server;
	
map<string,int> adv_win_client; 
    string s_adv_client;
    
map<string,int> adv_win_server;
	string s_adv_server;
	
int client_server, server_client;
//CLIENT
int sc,ac,uc,fc,pc,rc;
int sac;
int pfs=0; //PUSH + FLAGS;
int fa; //FIN+ACK;
int ufs; //URG + FLAGS
//SERVER 
int s_sc=0,s_ac=0,s_uc=0,s_fc=0,s_pc=0,s_rc=0,l=0;
int    s_sac=0;
int s_pfs=0;
int s_fa=0;
int s_ufs=0;

int wrap_c,seque_c1,seque_c2;
int wrap_s,seque_s1,seque_s2;
unsigned short int max_val;


/* Ethernet addresses are 6 bytes */
//#define ETHER_ADDR_LEN 6
//struct pcap_pkthdr *header;
/* Ethernet header */

/* IP header */
struct sniff_ip {
        u_char  ip_vhl;                 /* version << 4 | header length >> 2 */
        u_char  ip_tos;                 /* type of service */
        u_short ip_len;                 /* total length */
        u_short ip_id;                  /* identification */
        u_short ip_off;                 /* fragment offset field */
        #define IP_RF 0x8000            /* reserved fragment flag */
        #define IP_DF 0x4000            /* dont fragment flag */
        #define IP_MF 0x2000            /* more fragments flag */
        #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
        u_char  ip_ttl;                 /* time to live */
        u_char  ip_p;                   /* protocol */
        u_short ip_sum;                 /* checksum */
        struct  in_addr ip_src,ip_dst;  /* source and dest address */
};
#define IP_HL(ip)               (((ip)->ip_vhl) & 0x0f)
#define IP_V(ip)                (((ip)->ip_vhl) >> 4)


static int max_len=0,min_len=65536,pcount=0,start_time,end_time;


/* TCP header */
typedef u_int tcp_seq;

struct sniff_tcp {
        u_short th_sport;               /* source port */
        u_short th_dport;               /* destination port */
        tcp_seq th_seq;                 /* sequence number */
       // tcp_seq th_next;
        tcp_seq th_ack;                 /* acknowledgement number */
        u_char  th_offx2;               /* data offset, rsvd */
		#define TH_OFF(th)      (((th)->th_offx2 & 0xf0) >> 4)
        u_char  th_flags;
        #define TH_FIN  0x01
        #define TH_SYN  0x02
        #define TH_RST  0x04
        #define TH_PUSH 0x08
        #define TH_ACK  0x10
        #define TH_URG  0x20
        #define TH_ECE  0x40
        #define TH_CWR  0x80
        #define TH_FLAGS        (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
        u_short th_win;                 /* window */
        u_short th_sum;                 /* checksum */
        u_short th_urp;                 /* urgent pointer */
};

void
got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet);

struct details {
int tot_packets;
int unique_packets;
int sfc_no,syn_no,synack_no,ack_no,fin_no,finack_no;
int push_no,push_along_no,urg_no,urg_along_no,rst_no,seq_wrap,win_close;
char flag_push[100][100];
char flag_urg[100][100];
int psize,usize;
int cl_flag,se_flag;
int wrap_c;
int seque_c1,seque_c2;
int wrap_s,seque_s1,seque_s2;
//char ipcomp[100];
unsigned int seqno;
int win;
int win_c;
};
char prev_ipcomp[100][100];
        details ss[100];

 
void
got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{

static int count = 1; 
int start=1;/* packet counter */
/* declare pointers to packet headers */
const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
const struct sniff_ip *ip;              /* The IP header */
const struct sniff_tcp *tcp;            /* The TCP header */
int client_flag=0,server_flag=0;
int size_ip,j,index,diff;
int size_tcp,gcount=0,i_found=0,j_found;
//int size_payload;
pcount++;

//printf("\nPacket number %d:\n", count);
count++;
/* define ethernet header */
/* define/compute ip header offset */
ip = (struct sniff_ip*)(packet + SIZE_ETHERNET);
size_ip = IP_HL(ip)*4;

/*
*  OK, this packet is TCP.
*/
if(ip->ip_p == IPPROTO_TCP) 
{

char ipcomp[100]="",srip[100]="",dsip[100]="";
				int index1;

sprintf(ipcomp,"%s->",inet_ntoa(ip->ip_src));
sprintf(srip,"->%s",inet_ntoa(ip->ip_src));
char ipcomp1[100]="";
sprintf(ipcomp1,"%s",inet_ntoa(ip->ip_dst));
strcat(ipcomp,ipcomp1);
strcat(ipcomp1,srip);
//printf("\n%s\n",ipcomp1);
       for(j=0;j<l;j++)
       
       {
       	if(!strcmp(prev_ipcomp[j],ipcomp))
       	{
       	    i_found=1;
       	    index=j;
       	    break;
       	 }
       }
       if(i_found!=1)
       {
       	index=l;
       strcpy(prev_ipcomp[l],ipcomp);
       l++;
       ss[index].seqno=ntohl(tcp->th_seq);
       }
	ss[index].tot_packets++;

    int ack=0,syn=0,fin=0,rst=0,urg=0,ece=0,cwr=0,push=0,push_along=0,urg_along=0;
    			char urg_flags[100]="";			
    			char push_flags[100]="";
    			string p_s;
    			ostringstream p_s1;
				string p_s_s;
    			ostringstream p_s1_s;
    			
    			string c_win1;
				ostringstream c_win;
				string c_win1_s;
				ostringstream c_win_s;

/* define/compute tcp header offset */
    tcp = (struct sniff_tcp*)(packet + SIZE_ETHERNET + size_ip);
    size_tcp = TH_OFF(tcp)*4;

    	
    if(ntohs(tcp->th_sport)>1023)
    {
		ss[index].cl_flag=1;
		p_s1<<ntohs(header->len);
		p_s=p_s1.str();
		pack_size_client[p_s]++;
		
		c_win<<ntohs(tcp->th_win);
		c_win1=c_win.str();
		adv_win_client[c_win1]++;
		
	}
	else if(ntohs(tcp->th_sport)<1023)
	{
		p_s1_s<<ntohs(header->len);
		p_s_s=p_s1_s.str();
		pack_size_server[p_s_s]++;
		ss[index].se_flag=1;

		c_win_s<<ntohs(tcp->th_win);
		c_win1_s=c_win_s.str();
		adv_win_server[c_win1_s]++;
	}
	if(tcp->th_win==0)
		ss[index].win++;

    
    		if(ss[index].cl_flag==1)
            {
                 seque_c2=ntohs(tcp->th_seq);
                 
            }
            else 
            {
                 seque_c2=ntohs(tcp->th_seq);
                //memset(&max_val, 0xff, sizeof(unsigned short int));
                  //max_val = (max_val / 2) + 1;
                   diff = seque_c2-seque_c1;
                  
                  if(diff< -32678){
                  wrap_c++;
                  seque_c1=seque_c2;
                  }
                  else if(diff> 32768){
                  wrap_c++;
                  seque_c1=seque_c2;
                  }
                  else
                  seque_c1=seque_c2;
                  diff=0;
                  
              }
              if(ss[index].se_flag==1)
            {
                 seque_s2=ntohs(tcp->th_seq);
                 
            }
            else 
            {
                 seque_s2=ntohs(tcp->th_seq);
                
                  diff=seque_s2-seque_s1;
                  if(diff< -32768){
                  wrap_s++;
                  seque_s1=seque_s2;
                  }
                  else if(diff> 32768){
                  wrap_s++;
                  seque_s1=seque_s2;
                  }
                  else
                  seque_s1=seque_s2;
                  diff=0;
              }
    
    if((tcp->th_flags & TH_SYN)&&!(tcp->th_flags & TH_ACK)&&!(tcp->th_flags & TH_PUSH)
    &&!(tcp->th_flags & TH_URG)&&!(tcp->th_flags & TH_RST)&&!(tcp->th_flags & TH_FIN)
    &&!(tcp->th_flags & TH_ECE)&&!(tcp->th_flags & TH_CWR))
    {
 		start=1;
 		ss[index].syn_no++;
 	}
 	if((tcp->th_flags & TH_ACK)&&!(tcp->th_flags & TH_SYN)&&!(tcp->th_flags & TH_PUSH)
    &&!(tcp->th_flags & TH_URG)&&!(tcp->th_flags & TH_RST)&&!(tcp->th_flags & TH_FIN)
    &&!(tcp->th_flags & TH_ECE)&&!(tcp->th_flags & TH_CWR))
    {
 	//	start=1;
 		ss[index].ack_no++;
 	}
 	
 if((tcp->th_flags & TH_FIN)&&!(tcp->th_flags & TH_SYN)&&!(tcp->th_flags & TH_PUSH)
    &&!(tcp->th_flags & TH_URG)&&!(tcp->th_flags & TH_RST)&&!(tcp->th_flags & TH_ACK)
    &&!(tcp->th_flags & TH_ECE)&&!(tcp->th_flags & TH_CWR))
    {
 	//	start=1;
 		ss[index].fin_no++;
 	}
 	
        
 	    if(tcp->th_flags & TH_ACK)
 	    {
 	    	ack=1;
 	    	if(tcp->th_flags & TH_FIN)
 	    		ss[index].finack_no++;
 	    	if(tcp->th_flags & TH_SYN)
 	    		ss[index].synack_no++;
 	    }
 	    if(tcp->th_flags & TH_SYN)
 	    	syn=1;
 	    if(tcp->th_flags & TH_RST)
			rst=1;
 	    if(tcp->th_flags & TH_URG)
			urg=1;
 	    if(tcp->th_flags & TH_ECE)
 	    	ece=1;
 	    if(tcp->th_flags & TH_CWR)
			cwr=1;
		if(tcp->th_flags & TH_PUSH)
			push=1;
		if(tcp->th_flags & TH_FIN)
			fin=1;
			
		if(urg)
		{ int i=0;
			if(syn)
			{
				strcat(urg_flags,"SYN ");i++;
				urg_along=1;
			}
			if(ack){
				strcat(urg_flags,"ACK ");i++;
				urg_along=1;
				}
			if(rst){
				strcat(urg_flags,"RST ");i++;
				urg_along=1;
			}
			if(ece){
				strcat(urg_flags,"ECE ");i++;
				urg_along=1;
			}
			if(cwr){
				strcat(urg_flags,"CWR ");i++;
				urg_along=1;
			}
			if(push){
				strcat(urg_flags,"PUSH ");i++;
				urg_along=1;
			}
			if(urg_along)
			{
				ss[index].urg_along_no++;
				int us=ss[index].usize;
				sprintf(ss[index].flag_urg[us],"Packet No:%d:%s",count,urg_flags);
				ss[index].usize++;
			}
			else
				ss[index].urg_no++;

		}
		if(push)
		{ int i=0;

			if(syn)
			{
				strcat(push_flags,"SYN ");i++;
				push_along=1;
			}
			if(ack){
				strcat(push_flags,"ACK ");i++;
				push_along=1;
				}
			if(rst){
				strcat(push_flags,"RST ");i++;
				push_along=1;
			}
			if(ece){
				strcat(push_flags,"ECE ");i++;
				push_along=1;
			}
			if(cwr){
				strcat(push_flags,"CWR ");i++;
				push_along=1;
			}
			if(push){
				strcat(push_flags,"URG ");i++;
				push_along=1;
			}
			if(push_along)
			{
				ss[index].push_along_no++;
				int us=ss[index].psize;
				char temp[100]="";
				sprintf(temp,"Packet No:%d:%s",count,push_flags);
				strcpy(ss[index].flag_push[us],temp);
				ss[index].psize++;
			}
			else
							ss[index].push_no++;

		}
		if(fin)
		{
			if(ack)
				ss[index].finack_no++;
			if(ss[index].cl_flag)
			{
			printf("\nClient to Server\n");
			printf("Flow: %s\n",ipcomp);
			printf("No of packets in this flow:%d\n",ss[index].tot_packets);
			printf("No of SYN in this flow:%d\n",ss[index].syn_no);
			printf("No of ACK in this flow:%d\n",ss[index].ack_no);
			printf("No of FIN in this Flow:%d\n",ss[index].fin_no);
			printf("No of PUSH+others flow:%d\n",ss[index].push_along_no);
			printf("No of PUSH flow:%d\n",ss[index].push_no);
			printf("No of URG flow:%d\n",ss[index].urg_no);
			printf("No of URG+others flow:%d\n",ss[index].urg_along_no);
			printf("No of RST flow:%d\n",ss[index].rst_no);
			printf("No of FIN+ACK in this Flow:%d\n",ss[index].finack_no);
		//	printf("Types of flags with PUSH:\n");
			printf("Sequence No:%d\n",ss[index].seqno);
			printf("No of times Sequence No wrapped around:%d\n",ss[index].wrap_c);
			printf("No of times window closed:%d\n",ss[index].win);
			
			int ii;
			for(ii=0;ii<ss[index].psize;ii++)
				printf("%s\n",ss[index].flag_push[ii]);
			printf("Types of flags with URG:\n");
			
			for(ii=0;ii<ss[index].usize;ii++)
				printf("%s\n",ss[index].flag_urg[ii]);
			}
			//else
				for(j=0;j<l;j++)
       			{
       				if(!strcmp(prev_ipcomp[j],ipcomp1))
       				{
       	    			j_found=1;
       	    			index1=j;
       	    			break;
       	 			}
       			}
       		
			if(ss[index1].se_flag)
			{
			//	strcat(ipcomp1,ipcomp);
			printf("\nServer to Client\n");
			printf("Flow: %s\n",ipcomp1);
			printf("No of packets in this flow:%d\n",ss[index1].tot_packets);
			printf("No of SYN in this flow:%d\n",ss[index1].syn_no);
			printf("No of ACK in this flow:%d\n",ss[index1].ack_no);
			printf("No of FIN in this Flow:%d\n",ss[index1].fin_no);
			printf("No of PUSH+others flow:%d\n",ss[index1].push_along_no);
			printf("No of PUSH flow:%d\n",ss[index1].push_no);
			printf("No of URG flow:%d\n",ss[index1].urg_no);
			printf("No of URG+others flow:%d\n",ss[index1].urg_along_no);
			printf("No of RST flow:%d\n",ss[index1].rst_no);
			printf("No of FIN+ACK in this Flow:%d\n",ss[index1].finack_no);
			printf("Types of flags with PUSH:\n");
			printf("Sequence No:%d\n",ss[index1].seqno);
			printf("No of times Sequence No wrapped around:%d\n",ss[index1].wrap_s);
			printf("No of times window closed:%d\n",ss[index1].win);
			int ii;
			for(ii=0;ii<ss[index1].psize;ii++)
				printf("%s\n",ss[index1].flag_push[ii]);
			printf("Types of flags with URG:\n");
			
			for(ii=0;ii<ss[index1].usize;ii++)
				printf("%s\n",ss[index1].flag_urg[ii]);

       			
			}
		}
       
       
  
    
    }
    
}



int main(int argc, char **argv)
{

char errbuf[PCAP_ERRBUF_SIZE]; /* error buffer */
pcap_t *handle; /* packet capture handle */
const struct pcap_pkthdr *header;

char filter_exp[] = "ip"; /* filter expression [3] */
struct bpf_program fp; /* compiled filter program (expression) */
bpf_u_int32 mask; /* subnet mask */
bpf_u_int32 net; /* ip */
int num_packets =-1;/* number of packets to capture */



//struct ether_header *eptr;
/* check for capture device name on command-line */
if (argc == 2) {
// dev = argv[1];
}
else if (argc > 2) {
fprintf(stderr, "error: unrecognized command-line options\n\n");
exit(EXIT_FAILURE);
}
else {
handle = pcap_open_offline("wget.pcap", errbuf);
if (  handle==NULL ){
            printf( "error opening capture file!");
            return -1;
        }

}


/* now we can set our callback function */
pcap_loop(handle,num_packets, got_packet, NULL);

//printf("Packets in capture:%d\n",pcount);


/*printf("\nNetwork Layer Protocol\n");
printf("#packets\tProtocol\n");
printf("------------------------------------------------------------------------\n");
map<string, int>::const_iterator iter_pro;
    for (iter_pro=net_no_pack.begin(); iter_pro != net_no_pack.end(); ++iter_pro) {

//cout<< iter->first<<iter->second<<endl;
       
cout<< iter_pro->second<<"\t\t"<<iter_pro->first<<endl;

    }*/
printf("CLIENT->SERVER");
printf("# of Packets\t Window Size\n");

map<string, int>::const_iterator iter_cwin;
		    for (iter_cwin=adv_win_client.begin(); iter_cwin != adv_win_client.end(); ++iter_cwin) 
    		{
        
         		cout<< iter_cwin->second<<"\t\t"<<iter_cwin->first<<endl;

    		}

			adv_win_client.clear();
printf("SERVER->CLIENT");
printf("# of Packets\t Window Size\n");
map<string, int>::const_iterator iter_swin;
		    for (iter_swin=adv_win_server.begin(); iter_swin != adv_win_server.end(); ++iter_swin) 
    		{
        
         		cout<< iter_swin->second<<"\t\t"<<iter_swin->first<<endl;

    		}

			adv_win_client.clear();
printf("CLIENT->SERVER");
printf("# of packets\t Packet Size:\n");			
    map<string, int>::const_iterator iter_pak;
    for (iter_pak=pack_size_client.begin(); iter_pak != pack_size_client.end(); ++iter_pak) 
    {
        
 cout<< iter_pak->second<<"\t\t"<<iter_pak->first<<endl;

    }
    
    printf("SERVER->CLIENT");
printf("# of packets\t Packet Size:\n");			
    map<string, int>::const_iterator iter_pak_s;
    for (iter_pak_s=pack_size_server.begin(); iter_pak_s != pack_size_server.end(); ++iter_pak_s) 
    {
        
 cout<< iter_pak_s->second<<"\t\t"<<iter_pak_s->first<<endl;

    }




pcap_close(handle);
   return 0;
}
